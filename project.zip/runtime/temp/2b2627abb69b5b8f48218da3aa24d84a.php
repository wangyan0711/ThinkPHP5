<?php /*a:4:{s:54:"D:\www\project\application\admin\view\commit\list.html";i:1606110880;s:55:"D:\www\project\application\admin\view\public\basic.html";i:1604544225;s:57:"D:\www\project\application\admin\view\public\sideber.html";i:1600672403;s:53:"D:\www\project\application\admin\view\public\nav.html";i:1599016339;}*/ ?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>后台管理系统</title>

    <link href="/static/admin/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/admin/font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Toastr style -->
    <link href="/static/admin/css/plugins/toastr/toastr.min.css" rel="stylesheet">

    <!-- Gritter -->
    <link href="/static/admin/js/plugins/gritter/jquery.gritter.css" rel="stylesheet">

    <link href="/static/admin/css/animate.css" rel="stylesheet">
    <link href="/static/admin/css/style.css" rel="stylesheet">
    <link href="/static/admin/css/plugins/datapicker/datepicker3.css" rel="stylesheet">
</head>

<body>
<div id="wrapper">
    <nav class="navbar-default navbar-static-side" role="navigation">
        <!-- sidebar menu -->
<div class="sidebar-collapse">
    <ul class="nav metismenu" id="side-menu">
        <li class="nav-header">
            <div class="dropdown profile-element">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                    <span class="clear">
                        <span class="block m-t-xs">
                            <strong class="font-bold"><?php echo htmlentities((isset($admin['username']) && ($admin['username'] !== '')?$admin['username']:'')); ?></strong>
                        </span>
                        <span class="text-muted text-xs block">Welcome!</span>
                    </span>
                </a>
            </div>
            <div class="logo-element">
                Admin CP
            </div>
        </li>
        <li class="active"><a href="<?php echo url('/admin'); ?>"><i class="fa fa-th-large"></i> 控制台</a></li>
        <?php if(is_array($sidebar) || $sidebar instanceof \think\Collection || $sidebar instanceof \think\Paginator): $i = 0; $__LIST__ = $sidebar;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
        <li>
            <a href="#">
                <i class="<?php echo htmlentities($item['icon']); ?>"></i>
                <span class="nav-label"><?php echo htmlentities($item['title']); ?></span>
                <span class="fa arrow"></span>
            </a>
            <ul class="nav nav-second-level collapse">
                <?php if(is_array($item['child']) || $item['child'] instanceof \think\Collection || $item['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $item['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$_item): $mod = ($i % 2 );++$i;?>
                    <li>
                        <a href="<?php echo url($_item['url']); ?>"><?php echo htmlentities($_item['title']); ?></a>
                    </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </li>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </ul>
</div>





<!-- /sidebar menu -->
    </nav>
    <div id="page-wrapper" class="gray-bg">

    <!-- top navigation -->
    <div class="row border-bottom">
        <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
            </div>
            <ul class="nav navbar-top-links navbar-right">
                <li>
                    <span class="m-r-sm text-muted welcome-message">Welcome to Admin Theme.</span>
                </li>
                <li>
                    <a href="<?php echo url('/logout'); ?>">
                        <i class="fa fa-sign-out"></i> Log out
                    </a>
                </li>
            </ul>
        </nav>
    </div>
<!-- /top navigation -->

    
<!-- page content -->
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>评论管理</h2>
        <ol class="breadcrumb">
            <li>
                <a href="<?php echo url('/admin'); ?>">控制台</a>
            </li>
            <li class="active">
                <strong>评论列表</strong>
            </li>
        </ol>
    </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-content text-center">
                    <form role="form" action="<?php echo url('/admin/commit'); ?>" class="form-inline" method="get">
                        <div class="form-group">
                            <input type="text" placeholder="用户ID" name="user_id"
                                   value="" class="form-control">
                        </div>
                        <div class="form-group">
                            <select class="form-control" name="status">
                                <option value="0"  >全部</option>
                                <option value="1"  >待审核</option>
                                <option value="2"  >审核通过</option>
                                <option value="3"  >未通过</option>
                            </select>
                        </div>
                        <button class="btn btn-success" type="submit">搜索</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-content">
                    <table class="table table-bordered table-hover" style="font-size: 12px;">
                        <thead>
                        <tr>
                            <th>#ID</th>
                            <th>用户</th>
                            <th>评论内容</th>
                            <th>图片</th>
                            <th>评论时间</th>
                            <th>状态</th>
                            <th>操作</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
                        <tr>
                            <td><?php echo htmlentities($item['id']); ?></td>
                            <td><?php echo htmlentities($item['name']); ?></td>
                            <td><?php echo htmlentities($item['content']); ?></td>
                            <td>
                                <div id="photos_<?php echo htmlentities($item['id']); ?>" class="layer-photos-demo">
                                    <?php if(is_array($item['image']) || $item['image'] instanceof \think\Collection || $item['image'] instanceof \think\Paginator): $i = 0; $__LIST__ = $item['image'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                                    <img height="30px" attr_parid="photos_<?php echo htmlentities($item['id']); ?>" width="35px" onclick="photo(this)" layer-src="<?php echo htmlentities($v); ?>" src="<?php echo htmlentities($v); ?>" >
                                    <?php endforeach; endif; else: echo "" ;endif; ?>
                                </div>

                            </td>
                            <td><?php echo date('Y-m-d H:i:s',$item['time']); ?></td>
                            <td id="lock_<?php echo htmlentities($item['id']); ?>">
                                <?php if($item['status'] == 1): ?>
                                    <span class="label label-default radius">待审核</span>
                                <?php elseif($item['status'] == 3): ?>
                                    <span class="label label-warning radius">未通过</span>
                                <?php else: ?>
                                    <span class="label label-primary radius">审核通过</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if((permission('commit.deal'))): if(($item['status'] == 1)): ?>
                                    <a class="btn btn-xs btn-success btn-outline" title="点击处理"
                                       onclick="set_status('<?php echo htmlentities($item['id']); ?>')"> <span
                                            class="<?php if(($item['status'] == 0)): ?> fa fa-arrow-circle-up <?php else: ?> fa fa-arrow-circle-down <?php endif; ?>"> </span>
                                    </a>
                                    <?php else: ?>
                                    <a class="btn btn-xs btn-default btn-outline disabled">
                                        <span class="fa fa-check-circle"> </span>
                                    </a>
                                    <?php endif; ?>
                                <?php endif; if((permission('commit.delete'))): ?>
                                <a onclick="del_feedback('<?php echo htmlentities($item['id']); ?>')"
                                   class="btn btn-danger btn-outline btn-xs edit" title="删除"> <span
                                        class="fa fa-trash"></span> </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                        </tbody>
                    </table>
                    <div class="text-center">
                        <?php echo $list; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

        <!-- footer content -->
        <div class="footer">
            <div class="pull-right" id="jnkc">

            </div>
            <div>
                <strong>Copyright</strong> zhiErBei &copy; 2019-2020
            </div>
        </div>
        <!-- /footer content -->
    </div>
</div>
        <!-- jQuery -->
        <script src="/static/admin/js/jquery-2.1.1.js"></script>
        <script src="/static/admin/js/bootstrap.min.js"></script>
        <script src="/static/admin/js/plugins/metisMenu/jquery.metisMenu.js"></script>
        <script src="/static/admin/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

        <!-- Flot -->
        <script src="/static/admin/js/plugins/flot/jquery.flot.js"></script>
        <script src="/static/admin/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
        <script src="/static/admin/js/plugins/flot/jquery.flot.spline.js"></script>
        <script src="/static/admin/js/plugins/flot/jquery.flot.resize.js"></script>
        <script src="/static/admin/js/plugins/flot/jquery.flot.pie.js"></script>

        <!-- Peity -->
        <script src="/static/admin/js/plugins/peity/jquery.peity.min.js"></script>
        <script src="/static/admin/js/demo/peity-demo.js"></script>

        <!-- Custom and plugin javascript -->
        <script src="/static/admin/js/inspinia.js"></script>
        <script src="/static/admin/js/plugins/pace/pace.min.js"></script>

        <!-- jQuery UI -->
        <script src="/static/admin/js/plugins/jquery-ui/jquery-ui.min.js"></script>

        <!-- EayPIE -->
        <script src="/static/admin/js/plugins/easypiechart/jquery.easypiechart.js"></script>

        <!-- Sparkline -->
        <script src="/static/admin/js/plugins/sparkline/jquery.sparkline.min.js"></script>

        <!-- Sparkline demo data  -->
        <script src="/static/admin/js/demo/sparkline-demo.js"></script>

        <!-- Toastr -->
        <script src="/static/admin/js/plugins/toastr/toastr.min.js"></script>
        <script src="/static/common/layui-layer/layer.js"></script>
        <script src="/static/common/layui-layer/laydate/laydate.js"></script>
        <script src="/static/admin/js/admin-common.js"></script>


<script>

    function photo(v) {
        console.log($(v).attr('attr_parid'));
        layer.photos({
            photos: '#' + $(v).attr('attr_parid'),
            anim: 5 //0-6的选择，指定弹出图片动画类型，默认随机（请注意，3.0之前的版本用shift参数）
        });
    }

    function set_status(id) {
        layer.open({
            type: 2,
            title: '评论审核',
            shadeClose: false,
            shade: 0.8,
            area: ['400px', '400px'],
            content: "/admin/commitDeal/"+id
        });
    }
    function del_feedback(id) {
        layer.confirm('你确定删除该条记录吗？', {
            btn: ['确定', '取消']
        }, function () {
            $.ajax({
                type: "delete",
                'url': "/admin/commit/" + id,
                beforeSend: function () {
                layer.load(0);
            },
            success: function (data) {
                console.log(data);
                if (data.code == '0') {
                    layer.msg('删除成功！', {icon: 1, time: 800}, function () {
                        window.location.reload();
                    });
                } else {
                    layer.alert(data.msg);
                }
            },
            complete: function () {
                //完成响应
                layer.closeAll('loading');
            },
            error: function (data) {
                layer.alert('系统异常')
            }
        });
        });
    }

</script>

<script>
    url = window.location.pathname + window.location.search;
    url = url.replace(/(\/(p)\/\d+)|(&p=\d+)|(\/(id)\/\d+)|(&id=\d+)|(\/(group)\/\d+)|(&group=\d+)/, "");
    $("a[href='" + url + "']").parent().addClass("active") ;
    $("a[href='" + url + "']").parent().parent().parent().addClass("active") ;
</script>
</body>
</html>