<?php /*a:2:{s:53:"D:\www\project\application\admin\view\order\read.html";i:1605592801;s:56:"D:\www\project\application\admin\view\public\header.html";i:1603446534;}*/ ?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>后台管理系统</title>

    <link href="/static/admin/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/admin/font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Toastr style -->
    <link href="/static/admin/css/plugins/toastr/toastr.min.css" rel="stylesheet">

    <!-- Gritter -->
    <link href="/static/admin/js/plugins/gritter/jquery.gritter.css" rel="stylesheet">

    <link href="/static/admin/css/animate.css" rel="stylesheet">
    <link href="/static/admin/css/style.css" rel="stylesheet">
    <link href="/static/admin/css/plugins/datapicker/datepicker3.css" rel="stylesheet">
</head>

<body style="background-color: #ffffff">
<div id="wrapper gray-bg dashbard-1">
    
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-12">
        <h2>订单详情</h2>
        <div class="col-lg-4">
            <div class="ibox-content">
                <h3>收货信息：</h3>
                <p>
                    城市：<?php echo htmlentities($order_info['province']); ?>，<?php echo htmlentities($order_info['city']); ?>，<?php echo htmlentities($order_info['area']); ?><br/>
                    姓名：<?php echo htmlentities($order_info['name']); ?><br/>
                    联系电话：<?php echo htmlentities($order_info['phone']); ?><br/>
                    详细地址：<br/><?php echo htmlentities($order_info['addr']); ?>
                </p>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="ibox-content">
                <h3>订单状态：</h3>
                <?php if(($order_info['status'] == -1)): ?>
                <span class="label label-default radius">未支付</span>
                <?php elseif(($order_info['status'] == 1)): ?>
                <span class="label label-warning radius">待发货</span>
                <?php elseif(($order_info['status'] == 2)): ?>
                <span class="label label-success radius">已发货</span>
                <?php elseif(($order_info['status'] == 3)): ?>
                <span class="label label-primary radius">已完成</span>
                <?php endif; ?>
                <br>
                <br>
                <h3>时间：</h3>
                下单：<?php if($order_info['add_time']): ?><?php echo date('Y-m-d H:i:s',$order_info['add_time']); ?><?php endif; ?><br/>
                支付：<?php if($order_info['pay_time']): ?><?php echo date('Y-m-d H:i:s',$order_info['pay_time']); ?><?php endif; ?><br/>
                发货：<?php if($order_info['fahuo_time']): ?><?php echo date('Y-m-d H:i:s',$order_info['fahuo_time']); ?><?php endif; ?><br/>
                收货：<?php if($order_info['shou_time']): ?><?php echo date('Y-m-d H:i:s',$order_info['shou_time']); ?><?php endif; ?><br/>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="ibox-content">
                <?php if((permission('order.edit'))): if(($order_info['status'] == 1)): ?>
                <h3>订单操作：</h3>
                <p>
                    <button class="btn btn-outline btn-primary" onclick="fahuo('<?php echo htmlentities($order_info['id']); ?>')">发货</button>
                </p>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-content">
                    <p>订单号：<?php echo htmlentities($order_info['order_num']); ?>，金额：<?php echo htmlentities($order_info['pay_price']); ?></p>
                    <table class="table table-hover table-bordered">
                        <thead>
                        <tr>
                            <th>#ID</th>
                            <th>编号</th>
                            <th>商品详情</th>
                            <th>属性</th>
                            <th>单价</th>
                            <th>数量</th>
                            <th>状态</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(is_array($goods_order_list) || $goods_order_list instanceof \think\Collection || $goods_order_list instanceof \think\Paginator): $i = 0; $__LIST__ = $goods_order_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
                        <tr>
                            <td><?php echo htmlentities($item['id']); ?></td>
                            <td><?php echo htmlentities($item['order_goods_number']); ?></td>
                            <td class="text-l">
                                <a href="#">
                                    <?php if($item['goods_thumb']): ?>
                                    <img src="<?php echo htmlentities($item['goods_thumb']); ?>" style="width: 50px; height: 50px; display: block; float: left;margin-right: 10px;">
                                    <?php endif; ?>
                                    <span style="display: block;width: 300px;height:35px; float: left;"> <?php echo htmlentities($item['goods_name']); ?></span>
                                </a>
                            </td>
                            <td><?php echo htmlentities($item['attr']); ?></td>
                            <td><?php echo htmlentities($item['price']); ?></td>
                            <td>X<?php echo htmlentities($item['num']); ?></td>
                            <td>
                                <?php if(($item['status'] == -1)): ?>
                                <span class="label label-default radius">未支付</span>
                                <?php elseif(($item['status'] == 1)): ?>
                                <span class="label label-warning radius">待发货</span>
                                <?php elseif(($item['status'] == 2)): ?>
                                <span class="label label-success radius">已发货</span>
                                <?php elseif(($item['status'] == 3)): ?>
                                <span class="label label-primary radius">已完成</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>



</div>
<!-- jQuery -->
<script src="/static/admin/js/jquery-2.1.1.js"></script>
<script src="/static/admin/js/bootstrap.min.js"></script>
<script src="/static/admin/js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="/static/admin/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Flot -->
<script src="/static/admin/js/plugins/flot/jquery.flot.js"></script>
<script src="/static/admin/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
<script src="/static/admin/js/plugins/flot/jquery.flot.spline.js"></script>
<script src="/static/admin/js/plugins/flot/jquery.flot.resize.js"></script>
<script src="/static/admin/js/plugins/flot/jquery.flot.pie.js"></script>

<!-- Peity -->
<script src="/static/admin/js/plugins/peity/jquery.peity.min.js"></script>
<script src="/static/admin/js/demo/peity-demo.js"></script>

<!-- Custom and plugin javascript -->
<script src="/static/admin/js/inspinia.js"></script>
<script src="/static/admin/js/plugins/pace/pace.min.js"></script>

<!-- jQuery UI -->
<script src="/static/admin/js/plugins/jquery-ui/jquery-ui.min.js"></script>

<!-- EayPIE -->
<script src="/static/admin/js/plugins/easypiechart/jquery.easypiechart.js"></script>

<!-- Sparkline -->
<script src="/static/admin/js/plugins/sparkline/jquery.sparkline.min.js"></script>

<!-- Sparkline demo data  -->
<script src="/static/admin/js/demo/sparkline-demo.js"></script>

<!-- Toastr -->
<script src="/static/admin/js/plugins/toastr/toastr.min.js"></script>
<script src="/static/common/layui-layer/layer.js"></script>
<script src="/static/common/layui-layer/laydate/laydate.js"></script>
<script src="/static/admin/js/admin-common.js"></script>


<script>

    function fahuo(id) {
        layer.open({
            type: 2,
            title: '订单发货',
            shadeClose: false,
            shade: 0.8,
            area: ['400px', '400px'],
            content: "/admin/order_fahuo/"+id
        });
    }


</script>

</body>
</html>