<?php /*a:1:{s:54:"D:\www\project\application\admin\view\login\index.html";i:1599013879;}*/ ?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>管理员登陆 - 后台管理系统</title>

    <link href="/static/admin/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/admin/font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="/static/admin/css/animate.css" rel="stylesheet">
    <link href="/static/admin/css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">
<div class="loginColumns animated fadeInDown">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="ibox-content">
                <form class="form-horizontal" role="form" onsubmit="return false">
                    <div class="form-group">
                        <div class="col-md-12 text-center">
                            <h2 class="font-bold"><span class="fa fa-user"></span> 登录后台</h2>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <input type="text" class="form-control" name="username" placeholder="管理员名称" value="">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <input type="password" class="form-control" placeholder="密码" name="password">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-8">
                            <input type="text" class="form-control" placeholder="验证码" name="captcha" >
                        </div>
                        <div class="col-md-4">
                            <img src="<?php echo url('/admin/setVerifyCode'); ?>" onclick="this.src=this.src+'?'+Math.random()" style='width: 100px; height: 34px; float: right;cursor: pointer;'>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-primary btn-block login">
                                <i class="fa fa-btn fa-sign-in"></i> 登录
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Mainly scripts -->
<script src="/static/admin/js/jquery-2.1.1.js"></script>
<script src="/static/admin/js/bootstrap.min.js"></script>

<!-- layer -->
<script type="text/javascript" src="/static/common/layui-layer/layer.js"></script>

<script>
    $(".btn").click(function () {
        var username = $("*[name='username']").val();
        var password = $("*[name='password']").val();
        var captcha = $("*[name='captcha']").val();
        $.post("<?php echo url('/admin/login'); ?>", {username:username, password:password, captcha:captcha}, function (res) {
            if(res.code!=0){
                layer.tips(res.msg, '.btn', {
                    tips: [2, '#333'],
                    time: 0
                });
                $("*[name='captcha']").parent(".col-md-8").next(".col-md-4").find('img').click();
            }else{
                layer.load({
                    shade: 0.5,
                    time: 0,
                });
                setTimeout(function () {
                    window.location.href = '/admin';
                },1000)
            }
        });
    })
</script>
</body>
</html>