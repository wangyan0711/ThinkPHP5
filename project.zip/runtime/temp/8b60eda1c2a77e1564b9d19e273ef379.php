<?php /*a:4:{s:54:"D:\www\project\application\admin\view\system\list.html";i:1606189020;s:55:"D:\www\project\application\admin\view\public\basic.html";i:1604544225;s:57:"D:\www\project\application\admin\view\public\sideber.html";i:1600672403;s:53:"D:\www\project\application\admin\view\public\nav.html";i:1599016339;}*/ ?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>后台管理系统</title>

    <link href="/static/admin/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/admin/font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Toastr style -->
    <link href="/static/admin/css/plugins/toastr/toastr.min.css" rel="stylesheet">

    <!-- Gritter -->
    <link href="/static/admin/js/plugins/gritter/jquery.gritter.css" rel="stylesheet">

    <link href="/static/admin/css/animate.css" rel="stylesheet">
    <link href="/static/admin/css/style.css" rel="stylesheet">
    <link href="/static/admin/css/plugins/datapicker/datepicker3.css" rel="stylesheet">
</head>

<body>
<div id="wrapper">
    <nav class="navbar-default navbar-static-side" role="navigation">
        <!-- sidebar menu -->
<div class="sidebar-collapse">
    <ul class="nav metismenu" id="side-menu">
        <li class="nav-header">
            <div class="dropdown profile-element">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                    <span class="clear">
                        <span class="block m-t-xs">
                            <strong class="font-bold"><?php echo htmlentities((isset($admin['username']) && ($admin['username'] !== '')?$admin['username']:'')); ?></strong>
                        </span>
                        <span class="text-muted text-xs block">Welcome!</span>
                    </span>
                </a>
            </div>
            <div class="logo-element">
                Admin CP
            </div>
        </li>
        <li class="active"><a href="<?php echo url('/admin'); ?>"><i class="fa fa-th-large"></i> 控制台</a></li>
        <?php if(is_array($sidebar) || $sidebar instanceof \think\Collection || $sidebar instanceof \think\Paginator): $i = 0; $__LIST__ = $sidebar;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
        <li>
            <a href="#">
                <i class="<?php echo htmlentities($item['icon']); ?>"></i>
                <span class="nav-label"><?php echo htmlentities($item['title']); ?></span>
                <span class="fa arrow"></span>
            </a>
            <ul class="nav nav-second-level collapse">
                <?php if(is_array($item['child']) || $item['child'] instanceof \think\Collection || $item['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $item['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$_item): $mod = ($i % 2 );++$i;?>
                    <li>
                        <a href="<?php echo url($_item['url']); ?>"><?php echo htmlentities($_item['title']); ?></a>
                    </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </li>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </ul>
</div>





<!-- /sidebar menu -->
    </nav>
    <div id="page-wrapper" class="gray-bg">

    <!-- top navigation -->
    <div class="row border-bottom">
        <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
            </div>
            <ul class="nav navbar-top-links navbar-right">
                <li>
                    <span class="m-r-sm text-muted welcome-message">Welcome to Admin Theme.</span>
                </li>
                <li>
                    <a href="<?php echo url('/logout'); ?>">
                        <i class="fa fa-sign-out"></i> Log out
                    </a>
                </li>
            </ul>
        </nav>
    </div>
<!-- /top navigation -->

    
<!-- page content -->
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>系统配置</h2>
        <ol class="breadcrumb">
            <li>
                <a href="<?php echo url('/admin'); ?>">控制台</a>
            </li>
            <li class="active">
                <strong>系统配置</strong>
            </li>
        </ol>
    </div>
</div>
<div class="row">
    <div class="wrapper wrapper-content animated">
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <span>系统配置</span>
                </div>
                <div class="ibox-content">
                    <div class="tabs-container">
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#tab-1">网站基本配置</a></li>
<!--                            <li class=""><a data-toggle="tab" href="#tab-2">其他配置</a></li>-->
                        </ul>
                        <form class="form form-horizontal" id="update" method="post" action="<?php echo url('admin/system/updateSys'); ?>" enctype="multipart/form-data">
                            <div class="tab-content">
                                <div id="tab-1" class="tab-pane active">
                                    <div class="panel-body">
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['1']['remark']); ?></label>
                                            <div class="col-lg-9"><input type="text" name="<?php echo htmlentities($config['1']['id']); ?>" class="form-control" value="<?php echo htmlentities($config['1']['value']); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['2']['remark']); ?></label>
                                            <div class="col-lg-9"><input type="text" name="<?php echo htmlentities($config['2']['id']); ?>" class="form-control" value="<?php echo htmlentities($config['2']['value']); ?>">
                                            </div>
                                        </div>
<!--                                        <div class="form-group">-->
<!--                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['3']['remark']); ?></label>-->
<!--                                            <div class="col-lg-9 send">-->
<!--                                                <img id="preview" src="<?php echo htmlentities($config['3']['value']); ?>">-->
<!--                                                <input type="file" name="<?php echo htmlentities($config['3']['id']); ?>" id="doc" onchange="javascript:setImagePreview('doc');" />-->
<!--                                            </div>-->
<!--                                        </div>-->
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['4']['remark']); ?></label>
                                            <div class="col-lg-9"><input type="text" name="<?php echo htmlentities($config['4']['id']); ?>" class="form-control" value="<?php echo htmlentities($config['4']['value']); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['5']['remark']); ?></label>
                                            <div class="col-lg-9"><input type="text" name="<?php echo htmlentities($config['5']['id']); ?>" class="form-control" value="<?php echo htmlentities($config['5']['value']); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['6']['remark']); ?></label>
                                            <div class="col-lg-9"><input type="text" name="<?php echo htmlentities($config['6']['id']); ?>" class="form-control" value="<?php echo htmlentities($config['6']['value']); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['7']['remark']); ?></label>
                                            <div class="col-lg-9"><input type="text" name="<?php echo htmlentities($config['7']['id']); ?>" class="form-control" value="<?php echo htmlentities($config['7']['value']); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['8']['remark']); ?></label>
                                            <div class="col-lg-9"><input type="text" name="<?php echo htmlentities($config['8']['id']); ?>" class="form-control" value="<?php echo htmlentities($config['8']['value']); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['9']['remark']); ?></label>
                                            <div class="col-lg-9"><input type="text" name="<?php echo htmlentities($config['9']['id']); ?>" class="form-control" value="<?php echo htmlentities($config['9']['value']); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['10']['remark']); ?></label>
                                            <div class="col-lg-9"><input type="text" name="<?php echo htmlentities($config['10']['id']); ?>" class="form-control" value="<?php echo htmlentities($config['10']['value']); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['11']['remark']); ?></label>
                                            <div class="col-lg-9"><input type="text" name="<?php echo htmlentities($config['11']['id']); ?>" class="form-control" value="<?php echo htmlentities($config['11']['value']); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['18']['remark']); ?></label>
                                            <div class="col-lg-9"><input type="text" name="<?php echo htmlentities($config['18']['id']); ?>" class="form-control" value="<?php echo htmlentities($config['18']['value']); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['19']['remark']); ?></label>
                                            <div class="col-lg-9"><input type="text" name="<?php echo htmlentities($config['19']['id']); ?>" class="form-control" value="<?php echo htmlentities($config['19']['value']); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['12']['remark']); ?></label>
                                            <div class="col-lg-9">
                                                <textarea name="<?php echo htmlentities($config['12']['id']); ?>" class="form-control"><?php echo htmlentities($config['12']['value']); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['13']['remark']); ?></label>
                                            <div class="col-lg-9">
                                                <textarea name="<?php echo htmlentities($config['13']['id']); ?>" class="form-control"><?php echo htmlentities($config['13']['value']); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['14']['remark']); ?></label>
                                            <div class="col-lg-9">
                                                <textarea name="<?php echo htmlentities($config['14']['id']); ?>" class="form-control"><?php echo htmlentities($config['14']['value']); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['15']['remark']); ?></label>
                                            <div class="col-lg-9">
                                                <textarea name="<?php echo htmlentities($config['15']['id']); ?>" class="form-control"><?php echo htmlentities($config['15']['value']); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['16']['remark']); ?></label>
                                            <div class="col-lg-9">
                                                <textarea name="<?php echo htmlentities($config['16']['id']); ?>" class="form-control"><?php echo htmlentities($config['16']['value']); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['17']['remark']); ?></label>
                                            <div class="col-lg-9">
                                                <textarea name="<?php echo htmlentities($config['17']['id']); ?>" class="form-control"><?php echo htmlentities($config['17']['value']); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['20']['remark']); ?></label>
                                            <div class="col-lg-9"><input type="text" name="<?php echo htmlentities($config['20']['id']); ?>" class="form-control" value="<?php echo htmlentities($config['20']['value']); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['21']['remark']); ?></label>
                                            <div class="col-lg-9"><input type="text" name="<?php echo htmlentities($config['21']['id']); ?>" class="form-control" value="<?php echo htmlentities($config['21']['value']); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['22']['remark']); ?></label>
                                            <div class="col-lg-9"><input type="text" name="<?php echo htmlentities($config['22']['id']); ?>" class="form-control" value="<?php echo htmlentities($config['22']['value']); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['23']['remark']); ?></label>
                                            <div class="col-lg-9"><input type="text" name="<?php echo htmlentities($config['23']['id']); ?>" class="form-control" value="<?php echo htmlentities($config['23']['value']); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><?php echo htmlentities($config['24']['remark']); ?></label>
                                            <div class="col-lg-9"><input type="text" name="<?php echo htmlentities($config['24']['id']); ?>" class="form-control" value="<?php echo htmlentities($config['24']['value']); ?>">
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div id="tab-2" class="tab-pane">
                                    <div class="panel-body">


                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label"></label>
                                <div class="col-sm-9">
                                    <button type="submit" class="btn btn-success">保存配置</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

        <!-- footer content -->
        <div class="footer">
            <div class="pull-right" id="jnkc">

            </div>
            <div>
                <strong>Copyright</strong> zhiErBei &copy; 2019-2020
            </div>
        </div>
        <!-- /footer content -->
    </div>
</div>
        <!-- jQuery -->
        <script src="/static/admin/js/jquery-2.1.1.js"></script>
        <script src="/static/admin/js/bootstrap.min.js"></script>
        <script src="/static/admin/js/plugins/metisMenu/jquery.metisMenu.js"></script>
        <script src="/static/admin/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

        <!-- Flot -->
        <script src="/static/admin/js/plugins/flot/jquery.flot.js"></script>
        <script src="/static/admin/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
        <script src="/static/admin/js/plugins/flot/jquery.flot.spline.js"></script>
        <script src="/static/admin/js/plugins/flot/jquery.flot.resize.js"></script>
        <script src="/static/admin/js/plugins/flot/jquery.flot.pie.js"></script>

        <!-- Peity -->
        <script src="/static/admin/js/plugins/peity/jquery.peity.min.js"></script>
        <script src="/static/admin/js/demo/peity-demo.js"></script>

        <!-- Custom and plugin javascript -->
        <script src="/static/admin/js/inspinia.js"></script>
        <script src="/static/admin/js/plugins/pace/pace.min.js"></script>

        <!-- jQuery UI -->
        <script src="/static/admin/js/plugins/jquery-ui/jquery-ui.min.js"></script>

        <!-- EayPIE -->
        <script src="/static/admin/js/plugins/easypiechart/jquery.easypiechart.js"></script>

        <!-- Sparkline -->
        <script src="/static/admin/js/plugins/sparkline/jquery.sparkline.min.js"></script>

        <!-- Sparkline demo data  -->
        <script src="/static/admin/js/demo/sparkline-demo.js"></script>

        <!-- Toastr -->
        <script src="/static/admin/js/plugins/toastr/toastr.min.js"></script>
        <script src="/static/common/layui-layer/layer.js"></script>
        <script src="/static/common/layui-layer/laydate/laydate.js"></script>
        <script src="/static/admin/js/admin-common.js"></script>


<script>
    //下面用于图片上传预览功能
    function setImagePreview(id, avalue) {
        var docObj = document.getElementById(id);

        var imgObjPreview = document.getElementById("preview");
        if (docObj.files && docObj.files[0]) {
//火狐下，直接设img属性
            imgObjPreview.style.display = 'block';
            // imgObjPreview.style.width = '125px';
            // imgObjPreview.style.height = '125px';
//imgObjPreview.src = docObj.files[0].getAsDataURL();

//火狐7以上版本不能用上面的getAsDataURL()方式获取，需要一下方式
            imgObjPreview.src = window.URL.createObjectURL(docObj.files[0]);
        }
        else {
//IE下，使用滤镜
            docObj.select();
            var imgSrc = document.selection.createRange().text;
            var localImagId = document.getElementById("localImag");
//必须设置初始大小
            localImagId.style.width = "36px";
            localImagId.style.height = "36px";
//图片异常的捕捉，防止用户修改后缀来伪造图片
            try {
                localImagId.style.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=scale)";
                localImagId.filters.item("DXImageTransform.Microsoft.AlphaImageLoader").src = imgSrc;
            }
            catch (e) {
                alert("您上传的图片格式不正确，请重新选择!");
                return false;
            }
            imgObjPreview.style.display = 'none';
            document.selection.empty();
        }
        return true;
    }
</script>

<script>
    url = window.location.pathname + window.location.search;
    url = url.replace(/(\/(p)\/\d+)|(&p=\d+)|(\/(id)\/\d+)|(&id=\d+)|(\/(group)\/\d+)|(&group=\d+)/, "");
    $("a[href='" + url + "']").parent().addClass("active") ;
    $("a[href='" + url + "']").parent().parent().parent().addClass("active") ;
</script>
</body>
</html>