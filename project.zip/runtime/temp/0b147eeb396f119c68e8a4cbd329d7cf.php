<?php /*a:2:{s:54:"D:\www\project\application\admin\view\order\fahuo.html";i:1602497857;s:56:"D:\www\project\application\admin\view\public\header.html";i:1603446534;}*/ ?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>后台管理系统</title>

    <link href="/static/admin/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/admin/font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Toastr style -->
    <link href="/static/admin/css/plugins/toastr/toastr.min.css" rel="stylesheet">

    <!-- Gritter -->
    <link href="/static/admin/js/plugins/gritter/jquery.gritter.css" rel="stylesheet">

    <link href="/static/admin/css/animate.css" rel="stylesheet">
    <link href="/static/admin/css/style.css" rel="stylesheet">
    <link href="/static/admin/css/plugins/datapicker/datepicker3.css" rel="stylesheet">
</head>

<body style="background-color: #ffffff">
<div id="wrapper gray-bg dashbard-1">
    
<div class="row">
    <div class="wrapper wrapper-content animated">
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-content">
                    <form class="form-horizontal" id="form">
                        <div class="form-group"><label class="col-lg-2 control-label">请填写物流公司</label>
                            <div class="col-lg-9">
                                <input class="form-control" name="wuliu_gongsi" value="">
                            </div>
                        </div>
                        <div class="form-group"><label class="col-lg-2 control-label">请填写运单号</label>
                            <div class="col-lg-9">
                                <input class="form-control" name="wuliu_num" value="">
                            </div>
                        </div>
                        <div class="form-group"><label class="col-lg-2 control-label"></label>
                            <div class="col-lg-9">
                                <button type="button" class="btn btn-primary btn-block" id="sub" onclick="fahuo()">提交</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</div>
<!-- jQuery -->
<script src="/static/admin/js/jquery-2.1.1.js"></script>
<script src="/static/admin/js/bootstrap.min.js"></script>
<script src="/static/admin/js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="/static/admin/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Flot -->
<script src="/static/admin/js/plugins/flot/jquery.flot.js"></script>
<script src="/static/admin/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
<script src="/static/admin/js/plugins/flot/jquery.flot.spline.js"></script>
<script src="/static/admin/js/plugins/flot/jquery.flot.resize.js"></script>
<script src="/static/admin/js/plugins/flot/jquery.flot.pie.js"></script>

<!-- Peity -->
<script src="/static/admin/js/plugins/peity/jquery.peity.min.js"></script>
<script src="/static/admin/js/demo/peity-demo.js"></script>

<!-- Custom and plugin javascript -->
<script src="/static/admin/js/inspinia.js"></script>
<script src="/static/admin/js/plugins/pace/pace.min.js"></script>

<!-- jQuery UI -->
<script src="/static/admin/js/plugins/jquery-ui/jquery-ui.min.js"></script>

<!-- EayPIE -->
<script src="/static/admin/js/plugins/easypiechart/jquery.easypiechart.js"></script>

<!-- Sparkline -->
<script src="/static/admin/js/plugins/sparkline/jquery.sparkline.min.js"></script>

<!-- Sparkline demo data  -->
<script src="/static/admin/js/demo/sparkline-demo.js"></script>

<!-- Toastr -->
<script src="/static/admin/js/plugins/toastr/toastr.min.js"></script>
<script src="/static/common/layui-layer/layer.js"></script>
<script src="/static/common/layui-layer/laydate/laydate.js"></script>
<script src="/static/admin/js/admin-common.js"></script>


<script>
    function fahuo() {
        var wuliu_gongsi = $("*[name='wuliu_gongsi']").val();
        var wuliu_num = $("*[name='wuliu_num']").val();
        $.ajax({
            type: "post",
            data: {wuliu_gongsi:wuliu_gongsi, wuliu_num:wuliu_num},
            url: "<?php echo url('/admin/fahuo/'.$id); ?>",
            beforeSend: function () {
            layer.load(0);
        },
        success: function (data) {
            if (data.code == 0){
                layer.msg('发货成功！', {icon: 1, time:800}, function () {
                    parent.window.location.reload();
                });
            }else {
                layer.alert(data.msg);
            }
        },
        complete: function () {
            //完成响应
            layer.closeAll('loading');
        },
        error: function (data) {
            layer.alert('系统异常')
        }
    });
    }



</script>

</body>
</html>