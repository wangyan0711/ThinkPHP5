<?php /*a:4:{s:54:"D:\www\project\application\admin\view\admin\index.html";i:1597310794;s:55:"D:\www\project\application\admin\view\public\basic.html";i:1597303461;s:57:"D:\www\project\application\admin\view\public\sideber.html";i:1597221203;s:53:"D:\www\project\application\admin\view\public\nav.html";i:1597309769;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>后台管理系统</title>

    <!-- Bootstrap -->
    <link href="/static/common/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="/static/common/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="/static/common/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="/static/common/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- jVectorMap -->
    <link href="/static/admin/css/maps/jquery-jvectormap-2.0.3.css" rel="stylesheet"/>

    <!-- Custom Theme Style -->
    <link href="/static/common/build/css/custom.css" rel="stylesheet">
</head>

<body class="nav-md">
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <div class="navbar nav_title" style="border: 0;">
                    <a href="/admin" class="site_title"><i class="fa fa-paw"></i> <span>后台管理系统</span></a>
                </div>

                <div class="clearfix"></div>



<!-- sidebar menu -->
<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
    <div class="menu_section">
        <ul class="nav side-menu">
            <li><a href="/admin"><i class="fa fa-home"></i> 控制台 </a>
            </li>
            <li><a><i class="fa fa-edit"></i> Forms <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li><a href="form.html">General Form</a></li>
                    <li><a href="form_advanced.html">Advanced Components</a></li>
                    <li><a href="form_validation.html">Form Validation</a></li>
                    <li><a href="form_wizards.html">Form Wizard</a></li>
                    <li><a href="form_upload.html">Form Upload</a></li>
                    <li><a href="form_buttons.html">Form Buttons</a></li>
                </ul>
            </li>
            <li><a><i class="fa fa-desktop"></i> UI Elements <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li><a href="general_elements.html">General Elements</a></li>
                    <li><a href="media_gallery.html">Media Gallery</a></li>
                    <li><a href="typography.html">Typography</a></li>
                    <li><a href="icons.html">Icons</a></li>
                    <li><a href="glyphicons.html">Glyphicons</a></li>
                    <li><a href="widgets.html">Widgets</a></li>
                    <li><a href="invoice.html">Invoice</a></li>
                    <li><a href="inbox.html">Inbox</a></li>
                    <li><a href="calendar.html">Calendar</a></li>
                </ul>
            </li>
            <li><a><i class="fa fa-table"></i> Tables <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li><a href="tables.html">Tables</a></li>
                    <li><a href="tables_dynamic.html">Table Dynamic</a></li>
                </ul>
            </li>
            <li><a><i class="fa fa-bar-chart-o"></i> Data Presentation <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li><a href="chartjs.html">Chart JS</a></li>
                    <li><a href="chartjs2.html">Chart JS2</a></li>
                    <li><a href="morisjs.html">Moris JS</a></li>
                    <li><a href="echarts.html">ECharts</a></li>
                    <li><a href="other_charts.html">Other Charts</a></li>
                </ul>
            </li>
            <li><a><i class="fa fa-clone"></i>Layouts <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li><a href="fixed_sidebar.html">Fixed Sidebar</a></li>
                    <li><a href="fixed_footer.html">Fixed Footer</a></li>
                </ul>
            </li>
        </ul>
    </div>
    <div class="menu_section">
        <h3>Live On</h3>
        <ul class="nav side-menu">
            <li><a><i class="fa fa-bug"></i> Additional Pages <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li><a href="e_commerce.html">E-commerce</a></li>
                    <li><a href="projects.html">Projects</a></li>
                    <li><a href="project_detail.html">Project Detail</a></li>
                    <li><a href="contacts.html">Contacts</a></li>
                    <li><a href="profile.html">Profile</a></li>
                </ul>
            </li>
            <li><a><i class="fa fa-windows"></i> Extras <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li><a href="page_403.html">403 Error</a></li>
                    <li><a href="page_404.html">404 Error</a></li>
                    <li><a href="page_500.html">500 Error</a></li>
                    <li><a href="plain_page.html">Plain Page</a></li>
                    <li><a href="login.html">Login Page</a></li>
                    <li><a href="pricing_tables.html">Pricing Tables</a></li>
                </ul>
            </li>
            <li><a><i class="fa fa-sitemap"></i> Multilevel Menu <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li><a href="#level1_1">Level One</a>
                    <li><a>Level One<span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li class="sub_menu"><a href="level2.html">Level Two</a>
                            </li>
                            <li><a href="#level2_1">Level Two</a>
                            </li>
                            <li><a href="#level2_2">Level Two</a>
                            </li>
                        </ul>
                    </li>
                    <li><a href="#level1_2">Level One</a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>

</div>
<!-- /sidebar menu -->
</div>
</div>

<!-- top navigation -->
<div class="top_nav">
    <div class="nav_menu">
        <nav class="" role="navigation">
            <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
            </div>

            <ul class="nav navbar-nav navbar-right">
                <li class="">
                    <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                        <?php echo htmlentities((isset($admin['username']) && ($admin['username'] !== '')?$admin['username']:'')); ?>
                        <span class=" fa fa-angle-down"></span>
                    </a>
                    <ul class="dropdown-menu dropdown-usermenu pull-right">
                        <li><a href="<?php echo url('@admin/login/out'); ?>"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div>
</div>
<!-- /top navigation -->

<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>管理员管理</h3>
                <ol class="breadcrumb">
                    <li>
                        <a href="/admin">控制台</a>
                    </li>
                    <li class="active">
                        <strong>管理员列表</strong>
                    </li>
                </ol>
            </div>

            <div class="title_right">
                <div class="col-md-2 col-sm-2 col-xs-2 form-group pull-right">
                    <div class="input-group">
                        <a class="btn btn-default">添加管理员</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="ibox-content text-center">
                        <form id="form" role="form" action="<?php echo url('@admin/auth.admin/index'); ?>" class="form-inline" method="get">
                            <div class="form-group">
                                <input type="text" placeholder="用户名" name="username" value="<?php echo htmlentities($username); ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">查询</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>用户名</th>
                                <th>权限组</th>
                                <th>加入时间</th>
                                <th>最后登录时间</th>
                                <th>操作</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
                            <tr>
                                <th scope="row"><?php echo htmlentities($item['id']); ?></th>
                                <td><?php echo htmlentities($item['username']); ?></td>
                                <td>Otto</td>
                                <td><?php echo date('Y-m-d H:i:s',$item['create_time']); ?></td>
                                <td>@<?php echo date('Y-m-d H:i:s',$item['login_time']); ?></td>
                                <td>
                                    <a class="btn btn-success btn-xs" href="<?php echo url('@admin/admin'.$item['id']); ?>" title="编辑"><i class="fa fa-edit"></i></a>
                                    <?php if($item['id'] == 1): ?>
                                    <a class="btn btn-default btn-outline btn-xs disabled" title="删除"><i class="fa fa-trash"></i></a>
                                    <?php else: ?>
                                    <a onclick="" class="btn btn-danger btn-xs" title="删除"><span class="fa fa-trash"></span></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                            </tbody>
                        </table>
                        <?php echo $list; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


                <!-- jQuery -->
                <script src="/static/common/vendors/jquery/dist/jquery.min.js"></script>
                <!-- Bootstrap -->
                <script src="/static/common/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
                <!-- FastClick -->
                <script src="/static/common/vendors/fastclick/lib/fastclick.js"></script>
                <!-- NProgress -->
                <script src="/static/common/vendors/nprogress/nprogress.js"></script>
                <!-- Chart.js -->
                <script src="/static/common/vendors/Chart.js/dist/Chart.min.js"></script>
                <!-- gauge.js -->
                <script src="/static/common/vendors/bernii/gauge.js/dist/gauge.min.js"></script>
                <!-- bootstrap-progressbar -->
                <script src="/static/common/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
                <!-- iCheck -->
                <script src="/static/common/vendors/iCheck/icheck.min.js"></script>
                <!-- Skycons -->
                <script src="/static/common/vendors/skycons/skycons.js"></script>
                <!-- Flot -->
                <script src="/static/common/vendors/Flot/jquery.flot.js"></script>
                <script src="/static/common/vendors/Flot/jquery.flot.pie.js"></script>
                <script src="/static/common/vendors/Flot/jquery.flot.time.js"></script>
                <script src="/static/common/vendors/Flot/jquery.flot.stack.js"></script>
                <script src="/static/common/vendors/Flot/jquery.flot.resize.js"></script>
                <!-- Flot plugins -->
                <script src="/static/admin/js/flot/jquery.flot.orderBars.js"></script>
                <script src="/static/admin/js/flot/date.js"></script>
                <script src="/static/admin/js/flot/jquery.flot.spline.js"></script>
                <script src="/static/admin/js/flot/curvedLines.js"></script>
                <!-- jVectorMap -->
                <script src="/static/admin/js/maps/jquery-jvectormap-2.0.3.min.js"></script>
                <!-- bootstrap-daterangepicker -->
                <script src="/static/admin/js/moment/moment.min.js"></script>
                <script src="/static/admin/js/datepicker/daterangepicker.js"></script>

                <!-- Custom Theme Scripts -->
                <script src="/static/common/build/js/custom.min.js"></script>




</body>
</html>