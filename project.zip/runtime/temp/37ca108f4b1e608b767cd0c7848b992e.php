<?php /*a:4:{s:53:"D:\www\project\application\admin\view\admin\list.html";i:1600842305;s:55:"D:\www\project\application\admin\view\public\basic.html";i:1604544225;s:57:"D:\www\project\application\admin\view\public\sideber.html";i:1600672403;s:53:"D:\www\project\application\admin\view\public\nav.html";i:1599016339;}*/ ?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>后台管理系统</title>

    <link href="/static/admin/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/admin/font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Toastr style -->
    <link href="/static/admin/css/plugins/toastr/toastr.min.css" rel="stylesheet">

    <!-- Gritter -->
    <link href="/static/admin/js/plugins/gritter/jquery.gritter.css" rel="stylesheet">

    <link href="/static/admin/css/animate.css" rel="stylesheet">
    <link href="/static/admin/css/style.css" rel="stylesheet">
    <link href="/static/admin/css/plugins/datapicker/datepicker3.css" rel="stylesheet">
</head>

<body>
<div id="wrapper">
    <nav class="navbar-default navbar-static-side" role="navigation">
        <!-- sidebar menu -->
<div class="sidebar-collapse">
    <ul class="nav metismenu" id="side-menu">
        <li class="nav-header">
            <div class="dropdown profile-element">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                    <span class="clear">
                        <span class="block m-t-xs">
                            <strong class="font-bold"><?php echo htmlentities((isset($admin['username']) && ($admin['username'] !== '')?$admin['username']:'')); ?></strong>
                        </span>
                        <span class="text-muted text-xs block">Welcome!</span>
                    </span>
                </a>
            </div>
            <div class="logo-element">
                Admin CP
            </div>
        </li>
        <li class="active"><a href="<?php echo url('/admin'); ?>"><i class="fa fa-th-large"></i> 控制台</a></li>
        <?php if(is_array($sidebar) || $sidebar instanceof \think\Collection || $sidebar instanceof \think\Paginator): $i = 0; $__LIST__ = $sidebar;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
        <li>
            <a href="#">
                <i class="<?php echo htmlentities($item['icon']); ?>"></i>
                <span class="nav-label"><?php echo htmlentities($item['title']); ?></span>
                <span class="fa arrow"></span>
            </a>
            <ul class="nav nav-second-level collapse">
                <?php if(is_array($item['child']) || $item['child'] instanceof \think\Collection || $item['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $item['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$_item): $mod = ($i % 2 );++$i;?>
                    <li>
                        <a href="<?php echo url($_item['url']); ?>"><?php echo htmlentities($_item['title']); ?></a>
                    </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </li>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </ul>
</div>





<!-- /sidebar menu -->
    </nav>
    <div id="page-wrapper" class="gray-bg">

    <!-- top navigation -->
    <div class="row border-bottom">
        <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
            </div>
            <ul class="nav navbar-top-links navbar-right">
                <li>
                    <span class="m-r-sm text-muted welcome-message">Welcome to Admin Theme.</span>
                </li>
                <li>
                    <a href="<?php echo url('/logout'); ?>">
                        <i class="fa fa-sign-out"></i> Log out
                    </a>
                </li>
            </ul>
        </nav>
    </div>
<!-- /top navigation -->

    
<!-- page content -->
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>管理员管理</h2>
        <ol class="breadcrumb">
            <li>
                <a href="<?php echo url('/admin'); ?>">控制台</a>
            </li>
            <li class="active">
                <strong>管理员列表</strong>
            </li>
        </ol>
    </div>
    <?php if((permission('admin.add'))): ?>
    <div class="col-lg-2">
        <h2><a class="btn btn-primary btn-outline" href="<?php echo url('/admin/admin/create'); ?>">添加管理员</a></h2>
    </div>
    <?php endif; ?>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-content">
                    <table class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <th>#ID</th>
                            <th>用户名</th>
                            <th>权限组</th>
                            <th>加入时间</th>
                            <th>最后登录时间</th>
                            <th>操作</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
                        <tr>
                            <td><?php echo htmlentities($item['id']); ?></td>
                            <td><?php echo htmlentities($item['username']); ?></td>
                            <td><?php echo htmlentities($item['title']); ?></td>
                            <td><?php echo date('Y-m-d H:i:s',$item['create_time']); ?></td>
                            <td><?php echo date('Y-m-d H:i:s',$item['login_time']); ?></td>
                            <td>
                                <?php if((permission('admin.edit'))): ?>
                                <a class="btn btn-primary btn-outline btn-xs" href="<?php echo url('/admin/admin/'.$item['id'].'/edit'); ?>" title="编辑"><span class="fa fa-edit"></span></a>
                                <?php endif; if((permission('admin.delete'))): if($item['id'] == 1): ?>
                                    <a class="btn btn-default btn-outline btn-xs disabled" title="删除"><span class="fa fa-trash"></span></a>
                                <?php else: ?>
                                    <a onclick="del('<?php echo htmlentities($item['id']); ?>')" class="btn btn-danger btn-outline btn-xs" title="删除">
                                    <form name="delete-<?php echo htmlentities($item['id']); ?>" action="<?php echo url('admin/admin/'.$item['id']); ?>" method="post"><input type="hidden" name="_method" value="delete"></form>
                                    <span class="fa fa-trash"></span></a>
                                <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                        </tbody>
                    </table>
                    <div class="text-center">
                        <?php echo $list; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

        <!-- footer content -->
        <div class="footer">
            <div class="pull-right" id="jnkc">

            </div>
            <div>
                <strong>Copyright</strong> zhiErBei &copy; 2019-2020
            </div>
        </div>
        <!-- /footer content -->
    </div>
</div>
        <!-- jQuery -->
        <script src="/static/admin/js/jquery-2.1.1.js"></script>
        <script src="/static/admin/js/bootstrap.min.js"></script>
        <script src="/static/admin/js/plugins/metisMenu/jquery.metisMenu.js"></script>
        <script src="/static/admin/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

        <!-- Flot -->
        <script src="/static/admin/js/plugins/flot/jquery.flot.js"></script>
        <script src="/static/admin/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
        <script src="/static/admin/js/plugins/flot/jquery.flot.spline.js"></script>
        <script src="/static/admin/js/plugins/flot/jquery.flot.resize.js"></script>
        <script src="/static/admin/js/plugins/flot/jquery.flot.pie.js"></script>

        <!-- Peity -->
        <script src="/static/admin/js/plugins/peity/jquery.peity.min.js"></script>
        <script src="/static/admin/js/demo/peity-demo.js"></script>

        <!-- Custom and plugin javascript -->
        <script src="/static/admin/js/inspinia.js"></script>
        <script src="/static/admin/js/plugins/pace/pace.min.js"></script>

        <!-- jQuery UI -->
        <script src="/static/admin/js/plugins/jquery-ui/jquery-ui.min.js"></script>

        <!-- EayPIE -->
        <script src="/static/admin/js/plugins/easypiechart/jquery.easypiechart.js"></script>

        <!-- Sparkline -->
        <script src="/static/admin/js/plugins/sparkline/jquery.sparkline.min.js"></script>

        <!-- Sparkline demo data  -->
        <script src="/static/admin/js/demo/sparkline-demo.js"></script>

        <!-- Toastr -->
        <script src="/static/admin/js/plugins/toastr/toastr.min.js"></script>
        <script src="/static/common/layui-layer/layer.js"></script>
        <script src="/static/common/layui-layer/laydate/laydate.js"></script>
        <script src="/static/admin/js/admin-common.js"></script>


<script>
    url = window.location.pathname + window.location.search;
    url = url.replace(/(\/(p)\/\d+)|(&p=\d+)|(\/(id)\/\d+)|(&id=\d+)|(\/(group)\/\d+)|(&group=\d+)/, "");
    $("a[href='" + url + "']").parent().addClass("active") ;
    $("a[href='" + url + "']").parent().parent().parent().addClass("active") ;
</script>
</body>
</html>