<?php

namespace app\admin\model;

use think\Model;

class Company extends Model
{
    //
    /**
     * @var string  表名
     */
    protected $name   = 'company';

}
