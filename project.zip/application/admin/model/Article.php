<?php

namespace app\admin\model;

use think\Model;

class Article extends Model
{
    //
    /**
     * @var string  表名
     */
    protected $name   = 'article';
}
