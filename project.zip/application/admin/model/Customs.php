<?php

namespace app\admin\model;

use think\Model;

class Customs extends Model
{
    //
    /**
     * @var string  表名
     */
    protected $name   = 'customs';

}
