<?php

namespace app\admin\model;

use think\Model;

class ArticleCategory extends Model
{
    //
    /**
     * @var string  表名
     */
    protected $name   = 'article_category';
}
