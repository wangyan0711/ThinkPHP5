<?php

namespace app\admin\model;

use think\Model;

class Menu extends Model
{

    /**
     * @var string 表名
     */
    protected $name   = 'menu';
}
