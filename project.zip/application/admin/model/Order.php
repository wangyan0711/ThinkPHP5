<?php

namespace app\admin\model;

use think\Model;

class Order extends Model
{
    /**
     * @var string 表名
     */
    protected $name   = 'order_info';
}
