<?php

namespace app\api\model;

use think\Model;

class User extends Model
{
    //
    /**
     * @var string  表名
     */
    protected $name   = 'user';
}
