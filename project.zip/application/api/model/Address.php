<?php

namespace app\api\model;

use think\Model;

class Address extends Model
{
    //
    /**
     * @var string  表名
     */
    protected $name   = 'address';
}
